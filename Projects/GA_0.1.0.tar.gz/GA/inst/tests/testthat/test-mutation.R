## Test for mutation function

# Unit Tests
# 1. Check whether input is character vectors is.character == TRUE
# 2. Check whether the input is a nested list: is.list() == FALSE

test_that("Testing Mutation Function", {

  ## Sample input
  offspring <- "0001000110"

  ## Output
  mutated_offspring <- mutation(offspring, mu=0.1)

  ## Output should be a character vector (not list)
  expect_type(offspring, "character")

  ## Length of output should be the same length as Input
  expect_length(mutated_offspring, length(offspring))

  ## Length of chromosome should be the same for between input and output
  expect_length(mutated_offspring[-1], length(offspring[-1]))

})
