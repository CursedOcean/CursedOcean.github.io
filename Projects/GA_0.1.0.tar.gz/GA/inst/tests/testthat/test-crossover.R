## Test for crossover function

test_that("Testing crossover function", {

  ## Sample input
  parent <- list(c("0010", "1101"), c("1010", "0111"))

  ## Use crossover function
  children <- lapply(parent, crossover, pts=1) %>% unlist()
  ## Use crossover function with 2 crossover points
  children2 <- lapply(parent, crossover, pts=2) %>% unlist()

  ## Output should be a character vector
  expect_true(class(children) == "character")
  expect_true(class(children2) == "character")

  ## Length of output should be the same length as parents list
  expect_length(children, length(parent))

  ## Length of children chromosome should be the same as the parent's
  expect_true(nchar(children[1]) == nchar(parent[[1]][1]))

  ## Error if input is numeric
  expect_error(crossover(0010), "parents is not a character vector")

})
