#Tests
test_that("Sample input w/ 3 variables", {
  num_trials <- 100
  n <- 100
  num_correct <- 0
  for(i in 1:num_trials) {
    x1 <- runif(n)
    y <- x1 + rnorm(n, sd = 0.001)
    x2 <- 100 * runif(n)
    x3 <- 100 * runif(n)

    df <- data.frame(y, x1, x2, x3)
    mod <- select(df, "y", mut_rate = 0)

    AIC_vals <- c(AIC(lm(y~x1, df)), AIC(lm(y~x2, df)),
                  AIC(lm(y~x3, df)), AIC(lm(y~x1+x2, df)),
                  AIC(lm(y~x1+x3, df)), AIC(lm(y~x2+x3, df)),
                  AIC(lm(y~x1+x2+x3, df)))
    formulas <- c("x1", "x2", "x3", "x1 + x2", "x1 + x3",
                  "x2 + x3", "x1 + x2 + x3")

    index <- which.min(AIC_vals)
    if(mod$terms[[3]] == formulas[index]) {
      num_correct = num_correct + 1
    }
  }

  success_rate <- num_correct/num_trials

  expect_equal(class(mod), "lm")
  expect_true(success_rate >= 0.90)
  print("Test 1 done")
})

test_that("Sample with glm and 3 explanatory variables", {
  num_trials <- 100
  n <- 100
  num_correct <- 0
  for(i in 1:num_trials) {

    x1 <- rbinom(100, 4, prob=0.25)
    x2 <- rbinom(100, 2, prob=0.5)
    y <- x1+x2 ## Create y by using x1 and x2
    x3 <- rnorm(100, 100, sd=1)

    df <- data.frame(y, x1, x2, x3)
    mod <- select(df, "y", mut_rate = 0)

    AIC_vals <- c(AIC(glm(y~x1, df, family=poisson)), AIC(glm(y~x2, df, family=poisson)),
                  AIC(glm(y~x3, df, family=poisson)), AIC(glm(y~x1+x2, df, family=poisson)),
                  AIC(glm(y~x1+x3, df, family=poisson)), AIC(glm(y~x2+x3, df, family=poisson)),
                  AIC(glm(y~x1+x2+x3, df, family=poisson)))
    formulas <- c("x1", "x2", "x3", "x1 + x2", "x1 + x3",
                  "x2 + x3", "x1 + x2 + x3")

    index <- which.min(AIC_vals)
    if(mod$terms[[3]] == formulas[index]) {
      num_correct = num_correct + 1
    }
  }

  success_rate <- num_correct/num_trials

  expect_true(success_rate >= 0.7)
  print("Test 2 done")
})

test_that("Using custom fitness function", {
  cust_func <- function(mod_obj) {
    return(-length(mod_obj$coefficients))
  }

  num_trials <- 100
  n <- 100
  num_correct <- 0
  for(i in 1:num_trials) {
    x1 <- runif(n)
    y <- runif(n)
    x2 <- runif(n)
    x3 <- runif(n)
    x4 <- runif(n)
    x5 <- runif(n)

    df <- data.frame(y, x1, x2, x3, x4, x5)
    mod <- select(df, "y", fitfunc = cust_func, mut_rate = 0.01)

    if(length(mod$coefficients) == 6) {
      num_correct = num_correct + 1
    }
  }

  success_rate <- num_correct/num_trials

  expect_equal(class(mod), "lm")
  expect_true(success_rate >= 0.90)
  print("Test 3 done")
})
