test_that("Algorithm works (standard input)", {
  data <- data.frame(N = rnorm(100), X1 = rnorm(100), X2 = rnorm(100), X3 = rnorm(100))
  pop <- c("111", "101", "010", "110", "011", "100")

  result <- selection_alg(pop, data, AIC, verbose = F, iter = 1, model_type = lm,
                          rank = T, selec_mech = "FF", pop_size = 20)
  result2 <- selection_alg(pop, data, BIC, verbose = F, iter = 1, model_type =lm,
                           rank = T, selec_mech = "FF", pop_size = 20)
  result3 <- selection_alg(pop, data, AIC, verbose = F, iter = 1, model_type = lm,
                           rank = F, selec_mech = "FF", pop_size = 20)
  result4 <- selection_alg(pop, data, AIC, verbose = F, iter = 1, model_type = lm,
                           rank = T, selec_mech = "FR", pop_size = 20)

  expect_true(class(result) =="list")
  #Has a list of parents and a best fitness
  expect_equal(length(result), 2)
  #Has a list of parents the right length
  expect_equal(length(result[[1]]), 20)
  #Each element is pair of parents
  expect_equal(length(result[[1]][[1]]), 2)

  expect_true(class(result2) == "list")
  #Has a list of parents and a best fitness
  expect_equal(length(result2), 2)
  #Has a list of parents the right length
  expect_equal(length(result2[[1]]), 20)
  #Each element is pair of parents
  expect_equal(length(result2[[1]][[1]]), 2)

  expect_true(class(result3)=="list")
  #Has a list of parents and a best fitness
  expect_equal(length(result3), 2)
  #Has a list of parents the right length
  expect_equal(length(result3[[1]]), 20)
  #Each element is pair of parents
  expect_equal(length(result3[[1]][[1]]), 2)

  expect_true(class(result4)=="list")
  #Has a list of parents and a best fitness
  expect_equal(length(result4), 2)
  #Has a list of parents the right length
  expect_equal(length(result4[[1]]), 20)
  #Each element is pair of parents
  expect_equal(length(result4[[1]][[1]]), 2)
})
