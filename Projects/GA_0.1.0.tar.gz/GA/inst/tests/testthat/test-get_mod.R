test_that("Testing get_mod function (standard input)", {
  data <- data.frame(N = rnorm(100), X1 = rnorm(100), X2 = rnorm(100), X3 = rnorm(100))
  chroms <- c("101", "011")
  var_names <- c("N", "X1", "X2", "X3")
  mod_call <- get_mod(chroms, var_names)

  expect_equal(mod_call[1], "N~X1+X3")
  expect_equal(mod_call[2], "N~X2+X3")

  mod <- lm(mod_call[1], data)

  #expect_that(mod, is_a("lm"))
  expect_true(class(mod) == "lm")
  expect_equal(length(mod), 12)
  expect_true( class(mod$coefficients) == "numeric")
})
