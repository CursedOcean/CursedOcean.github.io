#' selection_algorithm
#'
#' @param pop
#' @param data
#' @param fitfunc
#' @param rank
#' @param model_type
#' @param selec_mech
#' @param verbose
#' @param iter
#' @param pop_size
#' @param ...
#'
#' @return
#'
#' @examples
selection_alg <- function(pop, data, fitfunc, rank, model_type, selec_mech,
                          verbose, iter, pop_size, ...) {

  #Make dataframe
  pop_df = as.data.frame(pop)

  #Add fitness column + order by fitness + add probability column
  #Prob column either based on rank or raw fitness score
  if(rank) {
    pop_mod <- pop_df %>% mutate(form = get_mod(pop, names(data))) %>%
      mutate(fitness = get_fitness(form, fitfunc, model_type, data, ...)) %>%
      arrange(fitness) %>%
      mutate(rank = n():1, prob = 2*rank/(length(pop)*(length(pop)+1)))
  } else {
    pop_mod <- pop_df %>% mutate(form = get_mod(pop, names(data))) %>%
      mutate(fitness = get_fitness(form, fitfunc, model_type, data, ...)) %>%
      arrange(fitness)
    fit_total <- sum(pop_mod$fitness)
    pop_mod <- mutate(pop_mod, prob = fitness/fit_total)
  }


  #Output information if verbose
  avg_fit <- mean(pop_mod$fitness)
  best_fit <- min(pop_mod$fitness)
  worst_fit <- max(pop_mod$fitness)
  if(verbose) {
    print(paste("Generation: ", iter, " Avg fitness: ", avg_fit,
                "Best fitness: ", best_fit, "Worst ", worst_fit))
  }

  #Select parents based on order
  #1 = both parents random based on fitness
  #2 = first parent based on fitness, 2nd random
  if (selec_mech == "FF") {
    parents <- lapply(1:pop_size, function(x){
      return(c(sample(pop_mod$pop, 2, prob = pop_mod$prob)))
    })
  } else if (selec_mech == "FR") {
    parents <- lapply(1:pop_size, function(x){
      return(c(sample(pop_mod$pop, 1, prob = pop_mod$prob), sample(pop_mod$pop, 1)))
    })
  }

  parents_fit = list("parents" = parents, "best_fit" = best_fit)
  return(parents_fit)
}
