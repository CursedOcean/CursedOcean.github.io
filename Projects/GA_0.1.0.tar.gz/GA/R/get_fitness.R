#' get_fitness
#'
#' @param form
#' @param fitfunc
#' @param model_type
#' @param data
#' @param ...
#'
#' @return
#'
#' @examples
get_fitness <- function(form, fitfunc, model_type, data, ...) {
  result <- sapply(form, function(x) {
    if(x == names(data)[1]) {
      return(Inf)
    }
    return(fitfunc(model_type(x, data, ...)))
  })
  return(result)
}
