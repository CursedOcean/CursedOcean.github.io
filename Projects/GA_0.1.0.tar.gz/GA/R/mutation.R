#' mutation
#'
#' @param off
#' @param mu
#'
#' @return
#'
#' @examples
mutation <- function(off, mu){
  offspring = unlist(str_split(off, ''))
  n = length(offspring)
  flip = rbinom(n=n, size = 1, prob = mu)
  flipTRUE = which(flip == 1)
  flipTRUE_len = length(flipTRUE)
  if(flipTRUE_len != 0){
    for (i in 1:flipTRUE_len) {
      if(offspring[flipTRUE[i]] == "1"){
        offspring[flipTRUE[i]] = "0"
      }
      else{
        offspring[flipTRUE[i]] = "1"
      }
    }
  }
  return(paste(unlist(offspring),collapse=""))
}
