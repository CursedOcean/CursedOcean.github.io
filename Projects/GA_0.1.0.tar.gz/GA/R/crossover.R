#' Crossover Operator
#'
#' @param parents
#' @param pts
#'
#' @return
#'
#' @examples
crossover <- function(parents, pts){

  ## Assertions - check that input is a character vector
  assert_that(is.character(parents))

  ## Get the length of the chromosome
  n <- nchar(parents[1])

  cross_points = sort(sample(1:(n-1), pts))

  child = list()

  for (i in 1:(pts+1)){
    parents_id = ifelse(i%%2 == 1, 1, 2)
    if (i == 1){
      child[i] = substr(parents[parents_id], start = 1, stop = cross_points[1])
    }
    else if (i == pts+1){
      child[i] = substr(parents[parents_id], start = cross_points[pts]+1, stop = n)
    }
    else{
      child[i] = substr(parents[parents_id], start = cross_points[i-1]+1, stop = cross_points[i])
    }
  }

  ## Return the offspring character strings
  child_produced = paste0(unlist(child),collapse="")
  return(child_produced)
}
