#' make_pop
#'
#' @param df
#' @param pop_size
#'
#' @return
#'
#' @examples
make_pop <- function(df, pop_size) {
  num_pred <- length(df) - 1

  # if we have odd number of pop_size, increases it by 1.
  if(pop_size %% 2 == 1){
    pop_size = pop_size+1
  }

  #Fill population with random individuals
  pop <- sapply(1:pop_size, function(x){
    chrom <- paste(sample(c(0,1), replace = T, size = num_pred), collapse = "")
    return(chrom)
  })

  return(pop)
}
