#' Genetic Algorithm for Model Selection
#'
#' @param data A required numeric data frame
#' @param target A required string specifying the name of the the response variable that we are regressing against
#' @param fitfunc A function which indicates the fitness criterion. The default is set to be AIC.
#' @param rank logical. If FALSE, rank will not apply to selection algorithm. The default is TRUE.
#' @param selec_mech "FF" or "FR". "FF" indicates both parents will be selected based on fitness.
#' "FR" indicates the first parent will be selected based on fitness, and the second one is random.
#' The default is "FF".
#' @param mut_rate An optional mutation rate. The default is 0.05
#' @param model_type A function which indicates the model type *lm, glm*. The default is *lm*.
#' @param max_iter An optional integer of the max iterations number. The default is 200.
#' @param crossover_pts An optional integer of genetic operators on crossover. The default is 1.
#' @param pop_size An optional integer of population size. If the input integer is an odd number, it will be increased by 1. The default is 20.
#' @param verbose logical. If TRUE, extra output on each generation will be displayed. The default is FALSE.
#' @param ...
#'
#' @return A model summary of model with selected predictors.
#' @import dplyr assertthat stringr testthat
#' @export
#' @examples
#' select(mtcars, "mpg")
#' select(mtcars, "mpg", fitfunc = BIC, verbose = T, crossover_pts = 2)

select <- function(data, target, fitfunc = AIC, rank = TRUE, selec_mech = "FF",
                   mut_rate = 0.05, model_type = lm, max_iter = 200,
                   crossover_pts = 1, pop_size = 20, verbose = FALSE, ...){

  #####################################################################
  ## Checks that user input is in an appropriate form
  #####################################################################

  ## data checks
  assert_that(is.data.frame(data), msg = "Data input is not a valid data frame")
  assert_that(length(data[1,]) >= 2, msg = "Dataframe does not have enough observations")
  assert_that(length(data[,1]) > 2, msg = "Dataframe does not have enough columns")
  assert_that(isTRUE(target %in% names(data)),
              msg = "Your target variable is not in your dataframe")

  ## target check
  assert_that(is.character(target), msg = "Your response variable (target) should be a string.")

  ## fitfunc check
  assert_that(is.function(fitfunc), msg = "Invalid fitness function")

  ## rank check
  assert_that(is.flag(rank), msg="Inputted rank is not boolean")

  ## selec_mech
  assert_that((selec_mech == "FF" | selec_mech == "FR"),
              msg = 'Invalid selection mechanism. Enter "FF" for
              both parents being selected based on fitness or
              "FR" for first parent being selected based on fitness and
              second being selected at random')

  ## mut_rate
  assert_that(is.numeric(mut_rate), msg="Mutation rate is not numeric")
  assert_that(are_equal(mut_rate > 1, FALSE), msg = "Mutation rate cannot exceed 1")
  assert_that(are_equal(mut_rate < 0, FALSE), msg = "Mutation rate must be positve")

  ## model_type
  assert_that(is.function(model_type), msg = "Model type must be a function, try entering lm or glm")
  ## Checks that model_type returns an "lm" object
  ## (Note: "glm" inherits "lm" so this works for either lm or glm as our model_type)
  assert_that(isTRUE("lm" %in% class( model_type(rnorm(5) ~ runif(5))) ),
              msg = "Output of your model_type is not an object of class 'lm' or 'glm'")

  ## max_iter
  assert_that(is.numeric(max_iter), msg = "Number of iterations must be numeric")
  assert_that(are_equal(max_iter > 0, TRUE), msg = "Number of iterations must be positive")
  assert_that(are_equal(max_iter <= 500, TRUE), msg = "Number of iterations cannot exceed 500")
  ## Check: what should be out maximum number of iterations?

  ## crossover_pts
  assert_that(crossover_pts <= floor((ncol(data) - 1) / 2),
              msg = "You have inputed too many crossover points. Please
              choose a number less than half of your possible explanatory variables.")

  ## pop_size
  assert_that(is.numeric(pop_size), msg = "Population size must be numeric")
  assert_that(are_equal(pop_size > 2, TRUE), msg = "Population size is too small")

  ## verbose
  assert_that(is.flag(verbose),
              msg = "Verbose should be boolean. Enter TRUE for additional output
              or FALSE for standard lm/glm output")


  #####################################################################
  ## Main Select Function: Return Model Summary
  #####################################################################

  ## Rearrange the data, make the first column always y
  y_var<-data[target]
  x_var = data[, names(data) != target]
  data = cbind(y_var, x_var)

  ## Make Population
  population = make_pop(data, pop_size)

  ## Generation Iteration
  fit_score = list()
  iter = 1
  best_repeated = 0
  repeated_limit = 10

  while (iter <= max_iter && best_repeated < repeated_limit) {
    parents_fit = selection_alg(pop = population, data = data, fitfunc = fitfunc, rank = rank,
                                model_type = model_type, selec_mech = selec_mech, verbose = verbose,
                                iter = iter, pop_size = pop_size, ...)
    parents = parents_fit[[1]]
    fit_score[iter] = parents_fit[[2]]
    childs = lapply(parents, crossover, pts = crossover_pts)
    next_generation = lapply(childs, mutation, mu = mut_rate)
    population = unlist(next_generation)
    if(iter != 1){
      if (fit_score[[iter]] == fit_score[[iter-1]]){
        best_repeated = best_repeated+1
      }
      else{
        best_repeated = 0
      }
    }
    iter = iter+1
  }

  # a final population will be returned from iterations as population
  selected_predictors <- as.logical(as.integer(strsplit(population[1], "")[[1]]))
  x_selected<-x_var[selected_predictors]

  # combine target column and selected predictors columns
  final_df = cbind(y_var, x_selected)
  # change target column name to y
  names(final_df)[names(final_df) == target] <- 'y'

  ## Fit model on this candidate
  return(lm(y~., data=final_df))
}
