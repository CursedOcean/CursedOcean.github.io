#' get_mod
#'
#' @param x
#' @param names
#'
#' @return
#'
#' @examples
get_mod <- function(x, names) {
  result <- sapply(1:length(x), function(k) {
    chrom_split <- strsplit(x[k], "")[[1]]
    ans <- paste0(names[1], '~')
    for(i in 1:length(chrom_split)) {
      if (chrom_split[i] == '1') {
        ans <- paste0(ans, names[i+1], '+')
      }
    }

    return(str_sub(ans, 1, length(ans) - 3))
  })

  return(result)
}
